=== Plugin Name ===
Contributors: zonglovani
Donate link: https://zonglovani.info/sponzori.html
Tags: juggling
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Kalendář žonglérských akcí

== Popis ==

Kalendář žonglérských akcí ze stránek zonglovani.info

== Instalace ==

1. Nahrajte soubor `zonglovani-info-kalendar.php` do adresáře `/wp-content/plugins/`
2. Aktuvujte plugin v nastavení WordPressu

== Změny ==

= 1.1 =
* Načítání dat přes https

= 1.0 =
* První verze
